// server.js
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Simulated traffic data
let trafficData = [
  { ip: "192.168.1.5", protocol: "TCP", size: "450B", time: "10:00:12", status: "normal" },
  { ip: "192.168.1.7", protocol: "UDP", size: "1200B", time: "10:00:15", status: "warning" },
  { ip: "10.0.0.2", protocol: "HTTP", size: "300B", time: "10:00:18", status: "normal" },
  { ip: "192.168.1.9", protocol: "TCP", size: "600B", time: "10:00:20", status: "alert" },
  { ip: "172.16.0.3", protocol: "UDP", size: "850B", time: "10:00:25", status: "normal" },
  { ip: "192.168.1.12", protocol: "HTTP", size: "2100B", time: "10:00:30", status: "normal" },
  { ip: "10.0.0.5", protocol: "TCP", size: "120B", time: "10:00:35", status: "warning" },
  { ip: "192.168.1.20", protocol: "TCP", size: "3400B", time: "10:00:40", status: "normal" },
];

// API endpoint
app.get('/api/traffic', (req, res) => {
  // Simulate random new packet
  const protocols = ["TCP", "UDP", "HTTP"];
  const statuses = ["normal", "warning", "alert"];
  const newPacket = {
    ip: `192.168.1.${Math.floor(Math.random() * 100 + 1)}`,
    protocol: protocols[Math.floor(Math.random() * protocols.length)],
    size: `${Math.floor(Math.random() * 5000 + 100)}B`,
    time: new Date().toLocaleTimeString('en-US', { hour12: false }),
    status: statuses[Math.floor(Math.random() * statuses.length)]
  };
  trafficData.push(newPacket);
  // Keep max 20 packets
  if (trafficData.length > 20) trafficData.shift();

  res.json(trafficData);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
