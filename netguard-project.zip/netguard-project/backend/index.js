// backend/index.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const { spawn } = require('child_process');
const WebSocket = require('ws');
const os = require('os');
const fs = require('fs');

const app = express();
const PORT = 3000;
const WS_PORT = 8080;

// ===== CONFIG =====
const CONFIG = {
  MAX_TRAFFIC_DATA: 100,
  MAX_ALERTS: 200,
  PACKET_BROADCAST_INTERVAL: 3,
  MAX_PACKETS_PER_IP: 100,
  CLEANUP_INTERVAL: 300000,
  TSHARK_RETRY_DELAY: 5000,
  TSHARK_MAX_RETRIES: 5
};

// ===== CORS =====
app.use(cors({ 
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'], 
  credentials: true 
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== ROUTES =====
app.get('/', (req,res)=>res.sendFile(path.join(__dirname,'../frontend/index.html')));
app.get('/analytics.html', (req,res)=>res.sendFile(path.join(__dirname,'../frontend/analytics.html')));
app.get('/alerts.html', (req,res)=>res.sendFile(path.join(__dirname,'../frontend/alerts.html')));

// ===== DATA =====
let trafficData = [];
let securityAlerts = [];
let wsConnections = new Set();
let analyticsData = {
  protocols: {TCP:0, UDP:0, HTTP:0, ICMP:0, DNS:0, Other:0},
  protocolCounts: {TCP:0, UDP:0, HTTP:0, ICMP:0, DNS:0, Other:0},
  sourceIPs: new Map(),
  destinationIPs: new Map(),
  bandwidth: {incoming:0, outgoing:0, peak:0},
  threats: {DDoS:0, PortScan:0, LargeTransfer:0, ICMPFlood:0, SQLi:0, XSS:0, Malware:0},
  stats: {
    totalPackets: 0, 
    threatsBlocked: 0, 
    activeSessions: 0, 
    uniqueIPs: 0, 
    packetsPerSecond: 0, 
    avgResponseTime: 24,
    uptime: Date.now()
  }
};
let timeSeriesData = {
  timestamps: [], 
  packetCounts: [], 
  bandwidthHistory: [],
  alertCounts: []
};

// ===== WEBSOCKET =====
const wss = new WebSocket.Server({ port: WS_PORT });
wss.on('connection', ws=>{
  console.log('🔗 WebSocket client connected');
  wsConnections.add(ws);
  
  ws.send(JSON.stringify({
    type:'INIT', 
    message:'Connected to NetGuard', 
    mode: tsharkProcess ? 'live' : 'demo',
    stats:{
      totalPackets: analyticsData.stats.totalPackets, 
      totalAlerts: securityAlerts.length
    }
  }));
  
  if (trafficData.length>0) {
    ws.send(JSON.stringify({
      type:'PACKETS_INIT', 
      data:trafficData.slice(-20).reverse()
    }));
  }
  
  if (securityAlerts.length>0) {
    ws.send(JSON.stringify({
      type:'ALERTS_INIT', 
      data:securityAlerts.slice(0,20)
    }));
  }

  ws.on('message', msg=>{
    try{ 
      const d = JSON.parse(msg); 
      if(d.type==='PING') ws.send(JSON.stringify({type:'PONG', timestamp:Date.now()}));
    } catch(e){}
  });
  
  ws.on('close', ()=>{
    console.log('🔌 WebSocket client disconnected');
    wsConnections.delete(ws);
  });
  ws.on('error', ()=>wsConnections.delete(ws));
});
console.log(`📡 WebSocket running on ws://localhost:${WS_PORT}`);

// ===== FUNCTIONS =====
function broadcast(data){
  const msg = JSON.stringify(data);
  wsConnections.forEach(ws=>{
    if(ws.readyState===WebSocket.OPEN) {
      try { ws.send(msg); } catch(e){}
    } else wsConnections.delete(ws);
  });
}

function isValidIP(ip){ 
  if (!ip) return false;
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(ip); 
}

function parseTsharkLine(parts){
  try {
    if(parts.length<3) return null;
    const src=parts[0]?.trim();
    if(!src || !isValidIP(src)) return null;
    const dest=parts[1]?.trim()||'Unknown';
    const size=parseInt(parts[2])||0;
    if (size <= 0) return null;
    
    let protocol = 'TCP';
    const protoRaw = parts[3]?.toUpperCase() || '';
    if (protoRaw.includes('UDP')) protocol = 'UDP';
    else if (protoRaw.includes('HTTP') || protoRaw.includes('HTTPS')) protocol = 'HTTP';
    else if (protoRaw.includes('TCP')) protocol = 'TCP';
    else if (protoRaw.includes('ICMP')) protocol = 'ICMP';
    else if (protoRaw.includes('DNS')) protocol = 'DNS';
    else protocol = 'Other';
    
    const status = size>10000 ? 'critical' : size>5000 ? 'warning' : 'normal';
    const ts = Date.now();
    
    return {
      ip: src, 
      dest, 
      protocol, 
      size: size+'B', 
      rawSize: size, 
      time: new Date(ts).toLocaleTimeString([], {hour12:false}), 
      timestamp: ts, 
      status, 
      id: `${src}-${ts}-${Math.random().toString(36).substr(2,6)}`
    };
  } catch(e) {
    return null;
  }
}

function updateAnalytics(packet){
  // Update protocol counts
  analyticsData.protocols[packet.protocol] = (analyticsData.protocols[packet.protocol] || 0) + 1;
  analyticsData.protocolCounts[packet.protocol] = (analyticsData.protocolCounts[packet.protocol] || 0) + 1;
  
  // Update source IPs
  analyticsData.sourceIPs.set(packet.ip, (analyticsData.sourceIPs.get(packet.ip) || 0) + 1);
  
  // Update destination IPs
  if (packet.dest && packet.dest !== 'Unknown') {
    analyticsData.destinationIPs.set(packet.dest, (analyticsData.destinationIPs.get(packet.dest) || 0) + 1);
  }
  
  // Update bandwidth
  analyticsData.bandwidth.incoming += packet.rawSize;
  if(analyticsData.bandwidth.incoming > analyticsData.bandwidth.peak) {
    analyticsData.bandwidth.peak = analyticsData.bandwidth.incoming;
  }
  analyticsData.bandwidth.outgoing += Math.floor(packet.rawSize * 0.7); // Approx outgoing
  
  // Update stats
  analyticsData.stats.totalPackets++;
  analyticsData.stats.uniqueIPs = analyticsData.sourceIPs.size;
  analyticsData.stats.activeSessions = analyticsData.sourceIPs.size;

  // Time series data (per second)
  const nowSec = new Date().getSeconds();
  if(timeSeriesData.timestamps.length===0 || timeSeriesData.timestamps[timeSeriesData.timestamps.length-1]!==nowSec){
    timeSeriesData.timestamps.push(nowSec);
    timeSeriesData.packetCounts.push(1);
    timeSeriesData.bandwidthHistory.push(packet.rawSize);
    timeSeriesData.alertCounts.push(0);
    
    if(timeSeriesData.timestamps.length>60){
      timeSeriesData.timestamps.shift();
      timeSeriesData.packetCounts.shift();
      timeSeriesData.bandwidthHistory.shift();
      timeSeriesData.alertCounts.shift();
    }
  } else {
    timeSeriesData.packetCounts[timeSeriesData.packetCounts.length-1]++;
    timeSeriesData.bandwidthHistory[timeSeriesData.bandwidthHistory.length-1] += packet.rawSize;
  }
  
  // Calculate packets per second
  const last10 = timeSeriesData.packetCounts.slice(-10);
  analyticsData.stats.packetsPerSecond = last10.length > 0 
    ? Math.round(last10.reduce((a,b)=>a+b,0) / last10.length) 
    : 0;
}

function detectThreats(packet){
  const threats=[];
  const now=Date.now();
  const oneMinAgo = now - 60000;
  
  // Recent packets from same IP
  const recent = trafficData.filter(p=> p.ip===packet.ip && p.timestamp > oneMinAgo);
  const packetCount = recent.length;
  
  // DDoS Detection
  if(packetCount > CONFIG.MAX_PACKETS_PER_IP){
    threats.push({
      type:'DDoS Attack', 
      severity:'critical', 
      title:'Potential DDoS Attack', 
      description:`${packetCount} packets/min from ${packet.ip}`, 
      source:packet.ip, 
      destination:packet.dest, 
      protocol:packet.protocol, 
      timestamp:now,
      metadata: { packetCount }
    });
    analyticsData.threats.DDoS++;
  }
  
  // Large Packet Detection
  if (packet.rawSize > 10000) {
    threats.push({
      type:'Large Data Transfer',
      severity:'medium',
      title:'Unusually Large Packet',
      description:`${packet.size} packet from ${packet.ip}`,
      source:packet.ip,
      destination:packet.dest,
      protocol:packet.protocol,
      timestamp:now,
      metadata: { size: packet.rawSize }
    });
    analyticsData.threats.LargeTransfer++;
  }
  
  return threats;
}

function createAlert(threat, packet){
  const ts = threat.timestamp || Date.now();
  return {
    id: `alert-${ts}-${Math.random().toString(36).substr(2,8)}`,
    severity: threat.severity,
    type: threat.type,
    title: threat.title,
    description: threat.description,
    source: threat.source,
    destination: threat.destination || packet.dest,
    protocol: threat.protocol || packet.protocol,
    time: new Date(ts).toLocaleTimeString([], {hour12:false}),
    timestamp: ts,
    status: 'new',
    read: false,
    metadata: threat.metadata || {}
  };
}

// ===== TSHARK SETUP =====
let tsharkProcess = null;
let tsharkRetries = 0;
let isRunningInDemoMode = false;

function findTshark(){
  const paths = [
    'C:\\Program Files\\Wireshark\\tshark.exe',
    'C:\\Program Files (x86)\\Wireshark\\tshark.exe',
    'tshark',
    '/usr/bin/tshark',
    '/usr/local/bin/tshark'
  ];
  for(const p of paths){ 
    try {
      fs.accessSync(p); 
      console.log(`✅ Tshark found at: ${p}`);
      return p;
    } catch(e){} 
  }
  console.log('⚠️ Tshark not found, will use demo mode');
  return null;
}

function getInterface(){
  try {
    const nets = os.networkInterfaces();
    for(const name in nets){
      for(const net of nets[name]){
        if(net.family==='IPv4' && !net.internal) {
          console.log(`🌐 Found active interface: ${name} (${net.address})`);
          return name;
        }
      }
    }
  } catch(e) {}
  return '2'; // fallback
}

function startDemoMode() {
  if (isRunningInDemoMode) return;
  isRunningInDemoMode = true;
  
  console.log('📊 Starting DEMO MODE with simulated traffic');
  
  const protocols = ['TCP', 'UDP', 'HTTP', 'ICMP', 'DNS'];
  const ips = [
    '192.168.1.10', '10.0.0.5', '172.16.0.8', '8.8.8.8', 
    '203.0.113.45', '198.51.100.78', '192.168.1.55'
  ];
  
  setInterval(() => {
    const isSuspicious = Math.random() > 0.85;
    const packet = {
      ip: ips[Math.floor(Math.random() * ips.length)],
      dest: '192.168.1.1',
      protocol: protocols[Math.floor(Math.random() * protocols.length)],
      size: Math.floor(Math.random() * 1500) + 'B',
      rawSize: Math.floor(Math.random() * 1500) + 64,
      time: new Date().toLocaleTimeString([], {hour12:false}),
      timestamp: Date.now(),
      status: isSuspicious ? 'warning' : 'normal',
      id: `demo-${Date.now()}-${Math.random()}`
    };
    
    trafficData.push(packet);
    if(trafficData.length > CONFIG.MAX_TRAFFIC_DATA) trafficData.shift();
    
    updateAnalytics(packet);
    
    // Random alerts
    if (Math.random() > 0.92) {
      const threatTypes = ['DDoS Attack', 'Port Scanning', 'Large Transfer', 'ICMP Flood'];
      const severities = ['critical', 'high', 'medium', 'low'];
      
      const alert = {
        id: `alert-${Date.now()}-${Math.random()}`,
        severity: severities[Math.floor(Math.random() * severities.length)],
        type: threatTypes[Math.floor(Math.random() * threatTypes.length)],
        title: 'Simulated Security Alert',
        description: `Demo: suspicious activity from ${packet.ip}`,
        source: packet.ip,
        destination: packet.dest,
        protocol: packet.protocol,
        time: packet.time,
        timestamp: Date.now(),
        status: 'new',
        read: false
      };
      
      securityAlerts.unshift(alert);
      if(securityAlerts.length > CONFIG.MAX_ALERTS) securityAlerts.pop();
      analyticsData.stats.threatsBlocked++;
      
      // Update threat counts
      if (alert.type.includes('DDoS')) analyticsData.threats.DDoS++;
      else if (alert.type.includes('Port')) analyticsData.threats.PortScan++;
      else if (alert.type.includes('Large')) analyticsData.threats.LargeTransfer++;
      
      broadcast({type: 'ALERT', data: alert});
    }
    
    broadcast({type: 'PACKET', data: packet});
    
  }, 800);
}

function startTshark(){
  if(tsharkProcess) {
    try { tsharkProcess.kill(); } catch(e) {}
  }
  
  const tsharkPath = findTshark();
  if (!tsharkPath) {
    startDemoMode();
    return;
  }
  
  const iface = getInterface();
  console.log(`🚀 Starting Tshark on interface ${iface}`);
  
  try {
    tsharkProcess = spawn(tsharkPath, [
      '-i', iface,
      '-l',
      '-T', 'fields',
      '-e', 'ip.src',
      '-e', 'ip.dst',
      '-e', 'frame.len',
      '-e', '_ws.col.Protocol',
      '-E', 'separator=,',
      '-E', 'quote=n',
      '-q'
    ]);
    
    let buffer = '';
    let packetCount = 0;
    let lastBroadcast = Date.now();
  
    tsharkProcess.stdout.on('data', data=>{
      buffer += data.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      const now = Date.now();
      
      for(const line of lines){
        if(!line.trim() || line.includes('capturing')) continue;
        const parts = line.split(',');
        const packet = parseTsharkLine(parts);
        if(!packet) continue;
        
        trafficData.push(packet);
        if(trafficData.length > CONFIG.MAX_TRAFFIC_DATA) trafficData.shift();
        
        updateAnalytics(packet);
        
        const threats = detectThreats(packet);
        threats.forEach(th=>{
          const alert = createAlert(th, packet);
          securityAlerts.unshift(alert);
          if(securityAlerts.length > CONFIG.MAX_ALERTS) securityAlerts.pop();
          analyticsData.stats.threatsBlocked++;
          
          // Update time series alert count
          if (timeSeriesData.alertCounts.length > 0) {
            timeSeriesData.alertCounts[timeSeriesData.alertCounts.length-1]++;
          }
          
          broadcast({type:'ALERT', data:alert});
        });
        
        packetCount++;
        if(packetCount % CONFIG.PACKET_BROADCAST_INTERVAL === 0 || now - lastBroadcast > 100){
          broadcast({type:'PACKET', data:packet});
          lastBroadcast = now;
        }
      }
    });
  
    tsharkProcess.stderr.on('data', err=>{
      const e = err.toString();
      if(e.includes('No such device')) {
        console.error(`❌ Interface "${iface}" not found!`);
      } else if (!e.includes('capturing') && !e.includes('packets')) {
        console.warn('⚠️ Tshark warning:', e);
      }
    });
    
    tsharkProcess.on('error', (err) => {
      console.error('❌ Tshark error:', err.message);
      if (!isRunningInDemoMode) startDemoMode();
    });
    
    tsharkProcess.on('close', code=>{
      console.warn(`⚠️ Tshark closed with code ${code}.`);
      if(tsharkRetries < CONFIG.TSHARK_MAX_RETRIES && !isRunningInDemoMode){
        tsharkRetries++;
        console.log(`🔄 Retry ${tsharkRetries}/${CONFIG.TSHARK_MAX_RETRIES} in 5s...`);
        setTimeout(startTshark, CONFIG.TSHARK_RETRY_DELAY);
      } else if (!isRunningInDemoMode) {
        console.log('📊 Switching to demo mode');
        startDemoMode();
      }
    });
    
    console.log('✅ Tshark started successfully - LIVE CAPTURE MODE');
    tsharkRetries = 0;
    
  } catch (error) {
    console.error('❌ Failed to start Tshark:', error);
    startDemoMode();
  }
}

// Start with a delay
setTimeout(() => {
  startTshark();
}, 1000);

// ===== API ENDPOINTS (FIXED - ALL REQUIRED) =====

// Health check - CRITICAL for frontend
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    mode: isRunningInDemoMode ? 'demo' : 'live',
    uptime: Math.floor((Date.now() - analyticsData.stats.uptime) / 1000),
    timestamp: Date.now(),
    stats: {
      totalPackets: analyticsData.stats.totalPackets,
      totalAlerts: securityAlerts.length,
      connections: wsConnections.size
    }
  });
});

// Traffic data
app.get('/api/traffic', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  res.json(trafficData.slice(-limit));
});

// Analytics data - COMPLETE with all fields frontend needs
app.get('/api/analytics', (req, res) => {
  // Calculate protocol percentages
  const total = Object.values(analyticsData.protocols).reduce((a, b) => a + b, 0);
  const protocolPercentages = {};
  Object.entries(analyticsData.protocols).forEach(([proto, count]) => {
    protocolPercentages[proto] = total > 0 ? Math.round((count / total) * 100) : 0;
  });
  
  // Get top source IPs
  const topSourceIPs = Array.from(analyticsData.sourceIPs.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([ip, count]) => ({ ip, count }));
  
  // Format traffic over time for charts
  const trafficOverTime = timeSeriesData.timestamps.map((t, i) => ({
    time: `${t}s`,
    packets: timeSeriesData.packetCounts[i] || 0,
    alerts: timeSeriesData.alertCounts[i] || 0,
    bandwidth: timeSeriesData.bandwidthHistory[i] || 0
  }));
  
  res.json({
    stats: analyticsData.stats,
    protocols: protocolPercentages,
    protocolCounts: analyticsData.protocolCounts,
    trafficOverTime: trafficOverTime,
    topSourceIPs: topSourceIPs,
    bandwidth: analyticsData.bandwidth,
    threats: analyticsData.threats,
    recentPackets: trafficData.slice(-20).reverse(),
    timestamp: Date.now()
  });
});

// Stats endpoint - for alerts count
app.get('/api/stats', (req, res) => {
  res.json({
    totalPackets: analyticsData.stats.totalPackets,
    totalAlerts: securityAlerts.length,
    unreadAlerts: securityAlerts.filter(a => !a.read).length,
    criticalAlerts: securityAlerts.filter(a => a.severity === 'critical').length,
    threatsBlocked: analyticsData.stats.threatsBlocked,
    activeSessions: analyticsData.stats.activeSessions,
    packetsPerSecond: analyticsData.stats.packetsPerSecond
  });
});

// Alerts endpoints
app.get('/api/alerts', (req, res) => {
  const { severity, status, limit = 50 } = req.query;
  let filtered = [...securityAlerts];
  
  if (severity) filtered = filtered.filter(a => a.severity === severity);
  if (status) filtered = filtered.filter(a => a.status === status);
  
  res.json({
    total: filtered.length,
    limit: parseInt(limit),
    data: filtered.slice(0, parseInt(limit))
  });
});

// Alert stats
app.get('/api/alerts/stats', (req, res) => {
  const stats = {
    critical: securityAlerts.filter(a => a.severity === 'critical').length,
    high: securityAlerts.filter(a => a.severity === 'high').length,
    medium: securityAlerts.filter(a => a.severity === 'medium').length,
    low: securityAlerts.filter(a => a.severity === 'low').length,
    total: securityAlerts.length,
    unread: securityAlerts.filter(a => !a.read).length,
    new: securityAlerts.filter(a => a.status === 'new').length,
    investigating: securityAlerts.filter(a => a.status === 'investigating').length,
    resolved: securityAlerts.filter(a => a.status === 'resolved').length
  };
  res.json(stats);
});

// Mark alert as read
app.put('/api/alerts/:id/read', (req, res) => {
  const id = req.params.id;
  const alert = securityAlerts.find(a => a.id === id);
  
  if (alert) {
    alert.read = true;
    broadcast({ type: 'ALERT_UPDATED', data: { id, read: true } });
    res.json({ success: true, alert });
  } else {
    res.status(404).json({ error: 'Alert not found' });
  }
});

// Resolve alert
app.put('/api/alerts/:id/resolve', (req, res) => {
  const id = req.params.id;
  const alert = securityAlerts.find(a => a.id === id);
  
  if (alert) {
    alert.status = 'resolved';
    alert.read = true;
    broadcast({ type: 'ALERT_UPDATED', data: { id, status: 'resolved' } });
    res.json({ success: true, alert });
  } else {
    res.status(404).json({ error: 'Alert not found' });
  }
});

// Clear alerts
app.post('/api/alerts/clear', (req, res) => {
  const { severity } = req.body;
  let beforeCount = securityAlerts.length;
  
  if (severity) {
    securityAlerts = securityAlerts.filter(a => a.severity !== severity);
  } else {
    securityAlerts = [];
  }
  
  res.json({ 
    success: true, 
    removed: beforeCount - securityAlerts.length,
    remaining: securityAlerts.length 
  });
});

// ===== CLEANUP =====
setInterval(() => { 
  analyticsData.bandwidth.incoming = 0; 
  analyticsData.bandwidth.outgoing = 0; 
}, CONFIG.CLEANUP_INTERVAL);

// ===== SERVER =====
app.listen(PORT, ()=>{
  console.log(`\n🚀 NetGuard Server Running!`);
  console.log(`================================`);
  console.log(`📊 Dashboard: http://localhost:${PORT}`);
  console.log(`📈 Analytics: http://localhost:${PORT}/analytics.html`);
  console.log(`🔔 Alerts: http://localhost:${PORT}/alerts.html`);
  console.log(`📡 WebSocket: ws://localhost:${WS_PORT}`);
  console.log(`================================\n`);
});