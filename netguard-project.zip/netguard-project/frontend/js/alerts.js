console.log("🚀 NetGuard Alerts System Initialized");

// ===== CONFIGURATION =====
const CONFIG = {
  REFRESH_INTERVAL: 3000, // 3 seconds
  API_ENDPOINTS: {
    alerts: '/api/alerts',
    alertStats: '/api/alerts/stats',
    stats: '/api/stats',
    health: '/api/health'
  },
  WS_URL: 'ws://localhost:8080'
};

// ===== ELEMENTS =====
const elements = {
  tableBody: document.getElementById("alertsTableBody"),
  searchInput: document.getElementById("searchAlerts"),
  activeAlertsCount: document.getElementById("activeAlertsCount"),
  headerActiveCount: document.getElementById("headerActiveCount"),
  modal: document.getElementById("alertDetailModal"),
  modalDetails: document.getElementById("modalAlertDetails"),
  closeModalBtn: document.getElementById("closeModal"),
  timeline: document.getElementById("threatTimeline"),
  refreshBtn: document.getElementById("refreshAlerts"),
  markAllReadBtn: document.getElementById("markAllRead"),
  clearAllBtn: document.getElementById("clearAll"),
  markAsReadBtn: document.getElementById("markAsReadBtn"),
  ignoreAlertBtn: document.getElementById("ignoreAlertBtn"),
  modeStatus: document.getElementById("modeStatus")
};

// ===== STATE MANAGEMENT =====
let alerts = []; // Will be populated from backend
let selectedAlertId = null;
let currentFilter = "all";
let searchTerm = "";
let wsConnection = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

/* =========================
   SEVERITY & STATUS COLOR MAPPING
========================= */
const severityColors = {
  critical: "severity-critical",
  high: "severity-high",
  medium: "severity-medium",
  low: "severity-low"
};

const statusColors = {
  unread: "status-new",
  read: "status-resolved",
  investigating: "status-investigating",
  resolved: "status-resolved",
  ignored: "status-ignored"
};

/* =========================
   CHECK BACKEND HEALTH
========================= */
async function checkBackendHealth() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.health);
    if (response.ok) {
      const data = await response.json();
      console.log(`✅ Backend connected - Mode: ${data.mode || 'live'}`);
      
      if (elements.modeStatus) {
        elements.modeStatus.textContent = data.mode === 'demo' ? 'DEMO' : 'LIVE';
        elements.modeStatus.style.color = data.mode === 'demo' ? 'var(--warning)' : 'var(--success)';
      }
      
      return true;
    }
    return false;
  } catch (error) {
    console.warn('⚠️ Backend not available');
    if (elements.modeStatus) {
      elements.modeStatus.textContent = 'OFFLINE';
      elements.modeStatus.style.color = 'var(--danger)';
    }
    return false;
  }
}

/* =========================
   FETCH ALERTS FROM BACKEND
========================= */
async function fetchAlerts() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.alerts + '?limit=100');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    
    if (data && data.data) {
      alerts = data.data;
    } else if (Array.isArray(data)) {
      alerts = data;
    } else {
      alerts = [];
    }
    
    // Apply current filters
    filterAndSearch();
    renderTimeline();
    updateActiveCount();
    
    return alerts;
  } catch (error) {
    console.error('Error fetching alerts:', error);
    
    // Show error in table
    if (elements.tableBody) {
      elements.tableBody.innerHTML = `
        <tr class="empty-state">
          <td colspan="8" style="text-align: center; padding: 4rem;">
            <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: var(--danger); margin-bottom: 1rem;"></i>
            <h3 style="color: var(--text-primary); margin-bottom: 0.5rem;">Failed to load alerts</h3>
            <p style="color: var(--text-secondary);">Could not connect to backend server</p>
            <button class="btn-action" style="margin-top: 1rem;" onclick="location.reload()">
              <i class="fas fa-sync-alt"></i> Retry
            </button>
          </td>
        </tr>
      `;
    }
    
    return [];
  }
}

/* =========================
   FETCH ALERT STATS
========================= */
async function fetchAlertStats() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.alertStats);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const stats = await response.json();
    
    // Update active count
    const activeCount = stats.new + stats.investigating;
    if (elements.activeAlertsCount) elements.activeAlertsCount.innerText = activeCount;
    if (elements.headerActiveCount) elements.headerActiveCount.innerText = activeCount;
    
    // Update sidebar badge
    const sidebarBadge = document.getElementById("activeAlertsCount");
    if (sidebarBadge) sidebarBadge.innerText = activeCount;
    
    return stats;
  } catch (error) {
    console.error('Error fetching alert stats:', error);
  }
}

/* =========================
   MARK ALERT AS READ
========================= */
async function markAlertAsRead(alertId) {
  try {
    const response = await fetch(`${CONFIG.API_ENDPOINTS.alerts}/${alertId}/read`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' }
    });
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const result = await response.json();
    
    if (result.success) {
      // Update local data
      const alert = alerts.find(a => a.id === alertId);
      if (alert) {
        alert.read = true;
        if (alert.status === 'unread') alert.status = 'read';
      }
      
      filterAndSearch();
      fetchAlertStats();
      
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error marking alert as read:', error);
    showNotification('Failed to mark alert as read', 'error');
    return false;
  }
}

/* =========================
   RESOLVE ALERT
========================= */
async function resolveAlert(alertId) {
  try {
    const response = await fetch(`${CONFIG.API_ENDPOINTS.alerts}/${alertId}/resolve`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' }
    });
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const result = await response.json();
    
    if (result.success) {
      // Update local data
      const alert = alerts.find(a => a.id === alertId);
      if (alert) {
        alert.status = 'resolved';
        alert.read = true;
      }
      
      filterAndSearch();
      fetchAlertStats();
      
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error resolving alert:', error);
    showNotification('Failed to resolve alert', 'error');
    return false;
  }
}

/* =========================
   MARK ALL ALERTS AS READ
========================= */
async function markAllAlertsRead() {
  try {
    // This would need a bulk operation endpoint
    // For now, mark each unread alert
    const unreadAlerts = alerts.filter(a => a.status === 'unread');
    
    for (const alert of unreadAlerts) {
      await markAlertAsRead(alert.id);
    }
    
    showNotification('All alerts marked as read', 'success');
    await fetchAlerts();
    await fetchAlertStats();
    
  } catch (error) {
    console.error('Error marking all as read:', error);
    showNotification('Failed to mark all as read', 'error');
  }
}

/* =========================
   CLEAR ALL ALERTS
========================= */
async function clearAllAlerts() {
  if (!confirm("⚠️ Are you sure you want to clear all alerts? This action cannot be undone.")) {
    return;
  }
  
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.alerts + '/clear', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const result = await response.json();
    
    if (result.success) {
      alerts = [];
      filterAndSearch();
      renderTimeline();
      updateActiveCount();
      showNotification(`Cleared ${result.removed} alerts`, 'warning');
    }
    
  } catch (error) {
    console.error('Error clearing alerts:', error);
    showNotification('Failed to clear alerts', 'error');
  }
}

/* =========================
   UPDATE ACTIVE COUNT
========================= */
function updateActiveCount() {
  const activeCount = alerts.filter(a => a.status === "unread" || a.status === "investigating").length;
  
  if (elements.activeAlertsCount) elements.activeAlertsCount.innerText = activeCount;
  if (elements.headerActiveCount) elements.headerActiveCount.innerText = activeCount;
  
  const sidebarBadge = document.getElementById("activeAlertsCount");
  if (sidebarBadge) sidebarBadge.innerText = activeCount;
}

/* =========================
   RENDER ALERTS TABLE
========================= */
function renderAlerts(data) {
  if (!elements.tableBody) return;
  
  elements.tableBody.innerHTML = "";

  if (!data || data.length === 0) {
    elements.tableBody.innerHTML = `
      <tr class="empty-state">
        <td colspan="8" style="text-align: center; padding: 4rem;">
          <i class="fas fa-shield-alt" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
          <h3 style="color: var(--text-primary); margin-bottom: 0.5rem;">No alerts found</h3>
          <p style="color: var(--text-secondary);">All systems are secure</p>
        </td>
      </tr>
    `;
    updateActiveCount();
    return;
  }

  data.forEach((alert, index) => {
    const row = document.createElement("tr");
    row.className = !alert.read ? "unread" : "";
    row.style.animationDelay = `${index * 0.05}s`;
    row.setAttribute("data-id", alert.id);
    
    // Format time from timestamp
    const timeStr = alert.time || (alert.timestamp ? new Date(alert.timestamp).toLocaleTimeString() : 'Unknown');
    
    row.addEventListener("click", (e) => {
      if (!e.target.closest('button') && !e.target.closest('input[type="checkbox"]')) {
        openModal(alert.id);
      }
    });

    row.innerHTML = `
      <td><input type="checkbox" onclick="event.stopPropagation()"></td>
      <td>
        <span class="severity-badge ${severityColors[alert.severity]}">
          ${(alert.severity || 'unknown').toUpperCase()}
        </span>
      </td>
      <td>
        <div class="alert-description">
          ${alert.title || alert.description || 'Unknown alert'}
          ${alert.count > 5 ? `<span class="alert-count-badge">${alert.count}</span>` : ''}
        </div>
      </td>
      <td><code class="ip-address">${alert.source || alert.ip || 'Unknown'}</code></td>
      <td><span class="protocol-badge">${alert.protocol || 'TCP'}</span></td>
      <td>
        <div class="time-cell">
          <i class="far fa-clock" style="opacity: 0.7;"></i>
          ${timeStr}
        </div>
      </td>
      <td>
        <span class="status-badge ${statusColors[alert.status] || 'status-new'}">
          <span class="status-dot"></span>
          ${(alert.status || 'new').toUpperCase()}
        </span>
      </td>
      <td>
        <button class="btn-action btn-primary view-btn" onclick="event.stopPropagation(); openModal('${alert.id}')">
          <i class="fas fa-eye"></i>
          <span>View</span>
        </button>
      </td>
    `;
    
    elements.tableBody.appendChild(row);
  });
}

/* =========================
   FILTER BUTTONS
========================= */
document.querySelectorAll(".filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    btn.style.transform = "scale(0.95)";
    setTimeout(() => btn.style.transform = "scale(1)", 200);

    document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    currentFilter = btn.dataset.filter;
    filterAndSearch();
  });
});

/* =========================
   SEARCH FUNCTIONALITY
========================= */
let searchTimeout;
if (elements.searchInput) {
  elements.searchInput.addEventListener("input", e => {
    searchTerm = e.target.value.toLowerCase();
    
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      filterAndSearch();
    }, 300);
  });
}

function filterAndSearch() {
  let filteredAlerts = [...alerts];

  // Apply severity filter
  if (currentFilter !== "all") {
    if (currentFilter === "unread") {
      filteredAlerts = filteredAlerts.filter(a => a.status === "unread" || !a.read);
    } else {
      filteredAlerts = filteredAlerts.filter(a => a.severity === currentFilter);
    }
  }

  // Apply search filter
  if (searchTerm) {
    filteredAlerts = filteredAlerts.filter(a =>
      (a.description && a.description.toLowerCase().includes(searchTerm)) ||
      (a.title && a.title.toLowerCase().includes(searchTerm)) ||
      (a.source && a.source.includes(searchTerm)) ||
      (a.ip && a.ip.includes(searchTerm)) ||
      (a.protocol && a.protocol.toLowerCase().includes(searchTerm)) ||
      (a.details && a.details.toLowerCase().includes(searchTerm))
    );
  }

  renderAlerts(filteredAlerts);
}

/* =========================
   MODAL HANDLING
========================= */
window.openModal = async function (id) {
  const alert = alerts.find(a => a.id === id);
  if (!alert) return;

  selectedAlertId = id;

  // Auto-mark as read when viewed
  if (!alert.read) {
    await markAlertAsRead(id);
  }

  const severityVar = alert.severity || 'info';
  const timeStr = alert.time || (alert.timestamp ? new Date(alert.timestamp).toLocaleString() : 'Unknown');

  if (elements.modalDetails) {
    elements.modalDetails.innerHTML = `
      <div class="modal-animation">
        <div class="detail-section">
          <h4><i class="fas fa-exclamation-triangle" style="color: var(--${severityVar});"></i> Alert Information</h4>
          <div class="detail-grid">
            <div class="detail-item">
              <span class="detail-label">Severity</span>
              <span class="detail-value">
                <span class="severity-badge ${severityColors[alert.severity]}">
                  ${(alert.severity || 'unknown').toUpperCase()}
                </span>
              </span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Status</span>
              <span class="detail-value">
                <span class="status-badge ${statusColors[alert.status] || 'status-new'}">
                  ${(alert.status || 'new').toUpperCase()}
                </span>
              </span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Type</span>
              <span class="detail-value"><code>${alert.type || alert.rule || 'N/A'}</code></span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Count</span>
              <span class="detail-value"><span class="count-badge">${alert.count || alert.metadata?.packetCount || 1}</span></span>
            </div>
          </div>
        </div>

        <div class="detail-section">
          <h4><i class="fas fa-info-circle"></i> Description</h4>
          <p class="detail-description">${alert.title || alert.description || 'No description'}</p>
          <p class="detail-detailed">${alert.details || alert.metadata?.description || 'No additional details available.'}</p>
        </div>

        <div class="detail-section">
          <h4><i class="fas fa-network-wired"></i> Network Details</h4>
          <div class="detail-grid">
            <div class="detail-item">
              <span class="detail-label">Source IP</span>
              <span class="detail-value"><code>${alert.source || alert.ip || 'Unknown'}</code></span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Source Port</span>
              <span class="detail-value"><code>${alert.sourcePort || alert.metadata?.sourcePort || 'N/A'}</code></span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Destination</span>
              <span class="detail-value"><code>${alert.destination || alert.dest || 'Unknown'}</code></span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Protocol</span>
              <span class="detail-value"><span class="protocol-badge">${alert.protocol || 'TCP'}</span></span>
            </div>
          </div>
        </div>

        <div class="detail-section">
          <h4><i class="far fa-clock"></i> Timeline</h4>
          <div class="detail-item">
            <span class="detail-label">Detected</span>
            <span class="detail-value">${timeStr}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Last Updated</span>
            <span class="detail-value">Just now</span>
          </div>
        </div>
      </div>
    `;
  }

  if (elements.modal) {
    elements.modal.classList.add("active");
    document.body.style.overflow = "hidden";
  }
};

if (elements.closeModalBtn) {
  elements.closeModalBtn.onclick = closeModal;
}

window.onclick = e => { 
  if (e.target === elements.modal) closeModal(); 
};

function closeModal() {
  if (elements.modal) elements.modal.classList.remove("active");
  document.body.style.overflow = "";
}

/* =========================
   MODAL ACTION BUTTONS
========================= */
if (elements.markAsReadBtn) {
  elements.markAsReadBtn.onclick = async () => {
    if (selectedAlertId) {
      const success = await markAlertAsRead(selectedAlertId);
      
      if (success) {
        elements.markAsReadBtn.innerHTML = '<i class="fas fa-check"></i> Marked!';
        elements.markAsReadBtn.style.background = "var(--success)";
        
        setTimeout(() => {
          closeModal();
          filterAndSearch();
          elements.markAsReadBtn.innerHTML = '<i class="fas fa-check"></i> Mark as Read';
          elements.markAsReadBtn.style.background = "";
        }, 500);
      }
    }
  };
}

if (elements.ignoreAlertBtn) {
  elements.ignoreAlertBtn.onclick = async () => {
    if (selectedAlertId) {
      // Mark as ignored (resolved with ignored status)
      const alert = alerts.find(a => a.id === selectedAlertId);
      if (alert) {
        alert.status = "ignored";
        alert.read = true;
        
        elements.ignoreAlertBtn.innerHTML = '<i class="fas fa-ban"></i> Ignored';
        elements.ignoreAlertBtn.style.background = "var(--text-muted)";
        
        setTimeout(() => {
          closeModal();
          filterAndSearch();
          fetchAlertStats();
          elements.ignoreAlertBtn.innerHTML = '<i class="fas fa-times-circle"></i> Ignore Alert';
          elements.ignoreAlertBtn.style.background = "";
        }, 500);
      }
    }
  };
}

/* =========================
   HEADER BUTTONS
========================= */
if (elements.markAllReadBtn) {
  elements.markAllReadBtn.onclick = async () => {
    elements.markAllReadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    elements.markAllReadBtn.disabled = true;
    
    await markAllAlertsRead();
    
    elements.markAllReadBtn.innerHTML = '<i class="fas fa-check-double"></i> Mark All Read';
    elements.markAllReadBtn.disabled = false;
  };
}

if (elements.clearAllBtn) {
  elements.clearAllBtn.onclick = async () => {
    await clearAllAlerts();
  };
}

if (elements.refreshBtn) {
  elements.refreshBtn.onclick = async () => {
    const icon = elements.refreshBtn.querySelector('i');
    if (icon) {
      icon.style.transform = 'rotate(360deg)';
      icon.style.transition = 'transform 0.5s ease';
    }
    
    elements.refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refreshing...';
    elements.refreshBtn.disabled = true;
    
    await fetchAlerts();
    await fetchAlertStats();
    
    if (icon) icon.style.transform = '';
    elements.refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
    elements.refreshBtn.disabled = false;
    
    showNotification("Alerts refreshed", "success");
  };
}

/* =========================
   NOTIFICATION SYSTEM
========================= */
function showNotification(message, type = "info") {
  const existingNotifications = document.querySelectorAll('.notification');
  existingNotifications.forEach(n => n.remove());

  const notification = document.createElement("div");
  
  const icon = type === 'success' ? 'fa-check-circle' : 
               type === 'warning' ? 'fa-exclamation-triangle' : 
               type === 'error' ? 'fa-exclamation-circle' :
               'fa-info-circle';
  
  notification.innerHTML = `
    <i class="fas ${icon}"></i>
    <span>${message}</span>
  `;
  
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--bg-elevated);
    border-left: 4px solid ${type === 'success' ? 'var(--success)' : type === 'warning' ? 'var(--warning)' : type === 'error' ? 'var(--danger)' : 'var(--info)'};
    color: var(--text-primary);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    box-shadow: var(--shadow-lg);
    z-index: 2000;
    display: flex;
    align-items: center;
    gap: 1rem;
    animation: slideIn 0.3s ease;
    border: 1px solid var(--border-light);
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = "fadeOut 0.3s ease";
    notification.style.opacity = "0";
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

/* =========================
   THREAT TIMELINE
========================= */
function renderTimeline() {
  if (!elements.timeline) return;
  
  elements.timeline.innerHTML = "";
  
  const severityGroups = {
    critical: alerts.filter(a => a.severity === "critical"),
    high: alerts.filter(a => a.severity === "high"),
    medium: alerts.filter(a => a.severity === "medium"),
    low: alerts.filter(a => a.severity === "low")
  };
  
  const maxCount = Math.max(
    severityGroups.critical.length,
    severityGroups.high.length,
    severityGroups.medium.length,
    severityGroups.low.length
  ) || 1;
  
  Object.entries(severityGroups).forEach(([severity, alerts]) => {
    const barWrapper = document.createElement("div");
    barWrapper.className = "timeline-bar-wrapper";
    
    const bar = document.createElement("div");
    bar.className = `timeline-bar ${severity} ${alerts.length === 0 ? 'empty' : ''}`;
    
    const height = alerts.length > 0 ? Math.max(30, (alerts.length / maxCount) * 150) : 20;
    bar.style.height = `${height}px`;
    bar.setAttribute("data-count", alerts.length);
    
    bar.title = alerts.length > 0 
      ? `${severity.toUpperCase()}: ${alerts.length} alert${alerts.length !== 1 ? 's' : ''}`
      : `${severity.toUpperCase()}: No alerts`;
    
    const label = document.createElement("span");
    label.className = "timeline-label";
    label.textContent = severity.toUpperCase();
    
    barWrapper.appendChild(bar);
    barWrapper.appendChild(label);
    elements.timeline.appendChild(barWrapper);
  });
}

/* =========================
   WEBSOCKET CONNECTION
========================= */
function initWebSocket() {
  try {
    wsConnection = new WebSocket(CONFIG.WS_URL);
    
    wsConnection.onopen = () => {
      console.log('🔗 WebSocket connected - receiving real-time alerts');
      reconnectAttempts = 0;
    };
    
    wsConnection.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'ALERT' || data.type === 'ALERTS') {
          // New alert received
          const newAlerts = data.data ? (Array.isArray(data.data) ? data.data : [data.data]) : [];
          
          if (newAlerts.length > 0) {
            // Add to alerts array
            alerts = [...newAlerts, ...alerts].slice(0, 200);
            
            // Re-render with current filter
            filterAndSearch();
            renderTimeline();
            fetchAlertStats();
            
            // Show notification for critical/high alerts
            const criticalAlert = newAlerts.find(a => a.severity === 'critical' || a.severity === 'high');
            if (criticalAlert) {
              showNotification(`🚨 ${criticalAlert.title || 'New Critical Alert'}`, 'warning');
            }
          }
        }
        
        if (data.type === 'ALERT_UPDATED') {
          // Alert status changed
          fetchAlerts();
          fetchAlertStats();
        }
        
        if (data.type === 'INIT' && data.mode) {
          if (elements.modeStatus) {
            elements.modeStatus.textContent = data.mode === 'demo' ? 'DEMO' : 'LIVE';
            elements.modeStatus.style.color = data.mode === 'demo' ? 'var(--warning)' : 'var(--success)';
          }
        }
        
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    wsConnection.onclose = () => {
      console.log('🔌 WebSocket disconnected');
      
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        setTimeout(initWebSocket, 3000);
      }
    };
    
    wsConnection.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
  } catch (error) {
    console.error('Failed to connect WebSocket:', error);
  }
}

/* =========================
   KEYBOARD SHORTCUTS
========================= */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && elements.modal && elements.modal.classList.contains('active')) {
    closeModal();
  }
});

/* =========================
   INITIALIZE
========================= */
async function initAlerts() {
  console.log('🔄 Initializing alerts...');
  
  const backendAvailable = await checkBackendHealth();
  
  if (backendAvailable) {
    await fetchAlerts();
    await fetchAlertStats();
    initWebSocket();
    
    // Set up periodic refresh (fallback)
    setInterval(async () => {
      if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
        await fetchAlerts();
        await fetchAlertStats();
      }
    }, CONFIG.REFRESH_INTERVAL);
    
  } else {
    // Backend not available
    showNotification('Backend server not connected', 'error');
    
    if (elements.tableBody) {
      elements.tableBody.innerHTML = `
        <tr class="empty-state">
          <td colspan="8" style="text-align: center; padding: 4rem;">
            <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: var(--danger); margin-bottom: 1rem;"></i>
            <h3 style="color: var(--text-primary); margin-bottom: 0.5rem;">Backend Not Connected</h3>
            <p style="color: var(--text-secondary);">Please start the backend server on port 3000</p>
            <button class="btn-action" style="margin-top: 1rem;" onclick="location.reload()">
              <i class="fas fa-sync-alt"></i> Retry Connection
            </button>
          </td>
        </tr>
      `;
    }
  }
}

// Start the alerts system
initAlerts();

console.log("✅ Alerts JS Loaded Successfully - Ready for real-time data");