console.log("📊 NetGuard Analytics Initialized - REAL-TIME MODE");

// ===== CONFIGURATION =====
const CONFIG = {
  REFRESH_INTERVAL: 3000, // 3 seconds
  API_ENDPOINTS: {
    analytics: '/api/analytics',
    traffic: '/api/traffic',
    alerts: '/api/alerts',
    stats: '/api/stats',
    health: '/api/health'
  },
  WS_URL: `ws://${window.location.hostname}:8080`,
  CHART_COLORS: {
    primary: '#3b82f6',
    success: '#10b981',
    warning: '#f59e0b',
    danger: '#ef4444',
    critical: '#dc2626',
    high: '#f97316',
    medium: '#f59e0b',
    low: '#eab308',
    purple: '#8b5cf6',
    pink: '#ec4899'
  }
};

// ===== DOM ELEMENTS =====
const elements = {
  // Stats
  totalRequests: document.getElementById('totalRequests'),
  avgResponseTime: document.getElementById('avgResponseTime'),
  threatsBlocked: document.getElementById('threatsBlocked'),
  activeSessions: document.getElementById('activeSessions'),
  
  // Chart values
  httpPercent: document.getElementById('httpPercent'),
  tcpPercent: document.getElementById('tcpPercent'),
  udpPercent: document.getElementById('udpPercent'),
  
  // Traffic stats
  peakTraffic: document.getElementById('peakTraffic'),
  lowTraffic: document.getElementById('lowTraffic'),
  avgTraffic: document.getElementById('avgTraffic'),
  
  // Threat counts
  criticalCount: document.getElementById('criticalCount'),
  highCount: document.getElementById('highCount'),
  mediumCount: document.getElementById('mediumCount'),
  lowCount: document.getElementById('lowCount'),
  
  // Response times
  avgResponse: document.getElementById('avgResponse'),
  p95Response: document.getElementById('p95Response'),
  p99Response: document.getElementById('p99Response'),
  
  // Bandwidth
  bandwidthIn: document.getElementById('bandwidthIn'),
  bandwidthOut: document.getElementById('bandwidthOut'),
  bandwidthTotal: document.getElementById('bandwidthTotal'),
  
  // Footer
  dataPoints: document.getElementById('dataPoints'),
  lastUpdated: document.getElementById('lastUpdated'),
  reportTime: document.getElementById('reportTime'),
  
  // Tables
  topSourcesBody: document.getElementById('topSourcesBody'),
  activityBody: document.getElementById('activityBody'),
  
  // Controls
  timeRange: document.getElementById('timeRange'),
  searchInput: document.getElementById('searchInput'),
  refreshBtn: document.getElementById('refreshAnalytics'),
  exportBtn: document.getElementById('exportBtn'),
  
  // Alert badge
  alertCount: document.getElementById('alertCount'),
  modeStatus: document.getElementById('modeStatus')
};

// ===== STATE MANAGEMENT =====
let analyticsData = {
  stats: {
    totalPackets: 0,
    avgResponseTime: 0,
    threatsBlocked: 0,
    activeSessions: 0,
    uniqueIPs: 0,
    packetsPerSecond: 0
  },
  protocols: {},
  protocolCounts: {},
  trafficOverTime: [],
  topSourceIPs: [],
  bandwidth: { incoming: 0, outgoing: 0, peak: 0 },
  threats: { DDoS: 0, PortScan: 0, LargeTransfer: 0, ICMPFlood: 0, SQLi: 0, XSS: 0, Malware: 0 }
};

let trafficData = [];
let wsConnection = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
let chartInstances = {};
let refreshInterval = null;
let isLive = true;

/* =========================
   CHECK BACKEND HEALTH
========================= */
async function checkBackendHealth() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    
    const response = await fetch(CONFIG.API_ENDPOINTS.health, {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log(`✅ Backend connected - Mode: ${data.mode || 'live'}`);
      
      if (elements.modeStatus) {
        elements.modeStatus.textContent = data.mode === 'demo' ? 'DEMO' : 'LIVE';
        elements.modeStatus.style.color = data.mode === 'demo' ? 'var(--warning)' : 'var(--success)';
      }
      
      isLive = data.mode !== 'demo';
      return true;
    }
    return false;
  } catch (error) {
    console.warn('⚠️ Backend not available:', error.message);
    if (elements.modeStatus) {
      elements.modeStatus.textContent = 'OFFLINE';
      elements.modeStatus.style.color = 'var(--danger)';
    }
    isLive = false;
    return false;
  }
}

/* =========================
   FETCH ANALYTICS DATA
========================= */
async function fetchAnalytics() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch(CONFIG.API_ENDPOINTS.analytics, {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    
    // Deep merge to preserve structure
    analyticsData = {
      ...analyticsData,
      ...data,
      stats: { ...analyticsData.stats, ...data.stats },
      threats: { ...analyticsData.threats, ...data.threats },
      bandwidth: { ...analyticsData.bandwidth, ...data.bandwidth }
    };
    
    // Update everything
    updateStats(data);
    updateProtocols(data);
    updateTrafficStats(data);
    updateThreatCounts(data);
    updateBandwidth(data);
    updateTopSources(data);
    updateCharts(data);
    updateLastUpdated();
    
    return data;
  } catch (error) {
    console.error('Error fetching analytics:', error);
    if (error.name === 'AbortError') {
      console.warn('Analytics fetch timeout');
    }
    return null;
  }
}

/* =========================
   FETCH TRAFFIC DATA
========================= */
async function fetchTrafficData() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    
    const response = await fetch(CONFIG.API_ENDPOINTS.traffic + '?limit=20', {
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    if (data && Array.isArray(data)) {
      trafficData = data;
      updateActivityTable(data);
    }
    return data;
  } catch (error) {
    console.error('Error fetching traffic:', error);
    return [];
  }
}

/* =========================
   FETCH ALERT COUNT
========================= */
async function fetchAlertCount() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.stats);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    
    if (elements.alertCount) {
      const unread = data.unreadAlerts || 0;
      elements.alertCount.textContent = unread;
      elements.alertCount.style.display = unread > 0 ? 'inline-block' : 'none';
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching alert count:', error);
  }
}

/* =========================
   UPDATE STATS CARDS
========================= */
function updateStats(data) {
  if (!data || !data.stats) return;
  
  const stats = data.stats;
  
  if (elements.totalRequests) {
    elements.totalRequests.textContent = formatNumber(stats.totalPackets || 0);
  }
  
  if (elements.avgResponseTime) {
    elements.avgResponseTime.textContent = (stats.avgResponseTime || 0) + 'ms';
  }
  
  if (elements.threatsBlocked) {
    elements.threatsBlocked.textContent = formatNumber(stats.threatsBlocked || 0);
  }
  
  if (elements.activeSessions) {
    elements.activeSessions.textContent = formatNumber(stats.activeSessions || 0);
  }
}

/* =========================
   UPDATE PROTOCOL PERCENTAGES
========================= */
function updateProtocols(data) {
  if (!data.protocols && !data.protocolCounts) return;
  
  const protocols = data.protocolCounts || data.protocols || {};
  const total = Object.values(protocols).reduce((a, b) => a + b, 0);
  
  if (total === 0) {
    if (elements.httpPercent) elements.httpPercent.textContent = '0%';
    if (elements.tcpPercent) elements.tcpPercent.textContent = '0%';
    if (elements.udpPercent) elements.udpPercent.textContent = '0%';
    return;
  }
  
  if (elements.httpPercent) {
    const httpPercent = Math.round((protocols.HTTP || 0) / total * 100);
    elements.httpPercent.textContent = httpPercent + '%';
  }
  
  if (elements.tcpPercent) {
    const tcpPercent = Math.round((protocols.TCP || 0) / total * 100);
    elements.tcpPercent.textContent = tcpPercent + '%';
  }
  
  if (elements.udpPercent) {
    const udpPercent = Math.round((protocols.UDP || 0) / total * 100);
    elements.udpPercent.textContent = udpPercent + '%';
  }
}

/* =========================
   UPDATE TRAFFIC STATS
========================= */
function updateTrafficStats(data) {
  if (!data.trafficOverTime || data.trafficOverTime.length === 0) {
    if (elements.peakTraffic) elements.peakTraffic.textContent = '0';
    if (elements.lowTraffic) elements.lowTraffic.textContent = '0';
    if (elements.avgTraffic) elements.avgTraffic.textContent = '0';
    return;
  }
  
  const values = data.trafficOverTime.map(t => t.packets || t.requests || 0);
  const peak = Math.max(...values);
  const low = Math.min(...values);
  const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  
  if (elements.peakTraffic) elements.peakTraffic.textContent = formatNumber(peak);
  if (elements.lowTraffic) elements.lowTraffic.textContent = formatNumber(low);
  if (elements.avgTraffic) elements.avgTraffic.textContent = formatNumber(avg);
}

/* =========================
   UPDATE THREAT COUNTS
========================= */
function updateThreatCounts(data) {
  if (!data.threats) return;
  
  const threats = data.threats;
  
  if (elements.criticalCount) elements.criticalCount.textContent = threats.DDoS || 0;
  if (elements.highCount) elements.highCount.textContent = threats.PortScan || 0;
  if (elements.mediumCount) elements.mediumCount.textContent = threats.LargeTransfer || 0;
  if (elements.lowCount) elements.lowCount.textContent = threats.ICMPFlood || 0;
}

/* =========================
   UPDATE BANDWIDTH
========================= */
function updateBandwidth(data) {
  if (!data.bandwidth) return;
  
  const bw = data.bandwidth;
  
  if (elements.bandwidthIn) elements.bandwidthIn.textContent = (bw.incoming || 0).toFixed(1);
  if (elements.bandwidthOut) elements.bandwidthOut.textContent = (bw.outgoing || 0).toFixed(1);
  if (elements.bandwidthTotal) {
    const total = (bw.incoming || 0) + (bw.outgoing || 0);
    elements.bandwidthTotal.textContent = total.toFixed(1);
  }
}

/* =========================
   UPDATE TOP SOURCES TABLE
========================= */
function updateTopSources(data) {
  if (!elements.topSourcesBody) return;
  
  if (!data.topSourceIPs || data.topSourceIPs.length === 0) {
    elements.topSourcesBody.innerHTML = `
      <tr>
        <td colspan="3" style="text-align: center; padding: 1rem; color: var(--text-secondary);">
          No source data available
        </td>
      </tr>
    `;
    return;
  }
  
  const sources = data.topSourceIPs.slice(0, 5);
  const total = sources.reduce((sum, s) => sum + s.count, 0);
  
  elements.topSourcesBody.innerHTML = sources.map(source => {
    const percentage = total > 0 ? Math.round((source.count / total) * 100) : 0;
    return `
      <tr>
        <td><code>${source.ip}</code></td>
        <td><strong>${formatNumber(source.count)}</strong></td>
        <td>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <div style="width: 60px; height: 4px; background: var(--border-light); border-radius: 2px;">
              <div style="width: ${percentage}%; height: 100%; background: var(--secondary); border-radius: 2px;"></div>
            </div>
            ${percentage}%
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

/* =========================
   UPDATE ACTIVITY TABLE
========================= */
function updateActivityTable(data) {
  if (!elements.activityBody) return;
  
  if (!data || data.length === 0) {
    elements.activityBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 2rem;">
          <p style="color: var(--text-secondary);">No recent activity</p>
        </td>
      </tr>
    `;
    return;
  }
  
  elements.activityBody.innerHTML = data.slice(0, 8).map(packet => {
    const statusClass = packet.status === 'critical' ? 'status-critical' : 
                       packet.status === 'warning' || packet.status === 'suspicious' ? 'status-warning' : 
                       'status-normal';
    
    const statusText = packet.status ? packet.status.toUpperCase() : 'NORMAL';
    
    return `
      <tr>
        <td>${packet.time || new Date(packet.timestamp).toLocaleTimeString()}</td>
        <td><code>${packet.ip || packet.source || 'Unknown'}</code></td>
        <td><code>${packet.dest || packet.destination || 'Unknown'}</code></td>
        <td><span class="protocol-badge">${packet.protocol || 'TCP'}</span></td>
        <td>${packet.size || formatBytes(packet.rawSize || 0)}</td>
        <td><span class="status-badge ${statusClass}">${statusText}</span></td>
      </tr>
    `;
  }).join('');
}

/* =========================
   UPDATE CHARTS WITH REAL DATA
========================= */
function updateCharts(data) {
  // Update Protocol Chart
  if (chartInstances.protocol && data.protocolCounts) {
    const counts = data.protocolCounts;
    chartInstances.protocol.data.datasets[0].data = [
      counts.HTTP || 0,
      counts.TCP || 0,
      counts.UDP || 0,
      counts.ICMP || 0,
      counts.DNS || 0,
      counts.Other || 0
    ];
    chartInstances.protocol.update();
  }
  
  // Update Traffic Chart
  if (chartInstances.traffic && data.trafficOverTime && data.trafficOverTime.length > 0) {
    const timeData = data.trafficOverTime.slice(-12);
    chartInstances.traffic.data.labels = timeData.map(t => t.time || '');
    chartInstances.traffic.data.datasets[0].data = timeData.map(t => t.packets || t.requests || 0);
    chartInstances.traffic.update();
  }
  
  // Update Threat Chart
  if (chartInstances.threat && data.threats) {
    chartInstances.threat.data.datasets[0].data = [
      data.threats.DDoS || 0,
      data.threats.PortScan || 0,
      data.threats.LargeTransfer || 0,
      data.threats.ICMPFlood || 0
    ];
    chartInstances.threat.update();
  }
  
  // Update Bandwidth Chart
  if (chartInstances.bandwidth && data.trafficOverTime) {
    const timeData = data.trafficOverTime.slice(-8);
    chartInstances.bandwidth.data.labels = timeData.map(t => t.time || '');
    
    // Use bandwidth history if available
    if (data.bandwidth && data.bandwidth.history) {
      chartInstances.bandwidth.data.datasets[0].data = data.bandwidth.history.incoming || [];
      chartInstances.bandwidth.data.datasets[1].data = data.bandwidth.history.outgoing || [];
    } else {
      // Generate from traffic data
      chartInstances.bandwidth.data.datasets[0].data = timeData.map(t => (t.bandwidth || t.packets || 0) * 0.8);
      chartInstances.bandwidth.data.datasets[1].data = timeData.map(t => (t.bandwidth || t.packets || 0) * 0.6);
    }
    
    chartInstances.bandwidth.update();
  }
}

/* =========================
   UPDATE LAST UPDATED
========================= */
function updateLastUpdated() {
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-US', { 
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  
  if (elements.lastUpdated) elements.lastUpdated.textContent = timeString;
  if (elements.reportTime) elements.reportTime.textContent = 'Live';
  if (elements.dataPoints) {
    elements.dataPoints.textContent = formatNumber(analyticsData.stats?.totalPackets || 0) + '+';
  }
}

/* =========================
   INITIALIZE CHARTS
========================= */
function initCharts() {
  // Protocol Distribution Chart (Doughnut)
  const protocolCtx = document.getElementById('protocolChart')?.getContext('2d');
  if (protocolCtx) {
    chartInstances.protocol = new Chart(protocolCtx, {
      type: 'doughnut',
      data: {
        labels: ['HTTP/HTTPS', 'TCP', 'UDP', 'ICMP', 'DNS', 'Other'],
        datasets: [{
          data: [0, 0, 0, 0, 0, 0],
          backgroundColor: [
            CONFIG.CHART_COLORS.primary,
            CONFIG.CHART_COLORS.success,
            CONFIG.CHART_COLORS.warning,
            CONFIG.CHART_COLORS.danger,
            CONFIG.CHART_COLORS.purple,
            CONFIG.CHART_COLORS.pink
          ],
          borderWidth: 0,
          borderRadius: 8,
          spacing: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'var(--bg-elevated)',
            titleColor: 'var(--text-primary)',
            bodyColor: 'var(--text-secondary)',
            borderColor: 'var(--border-light)',
            borderWidth: 1,
            padding: 12,
            cornerRadius: 8,
            callbacks: {
              label: (context) => {
                const label = context.label || '';
                const value = context.raw || 0;
                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                return `${label}: ${formatNumber(value)} (${percentage}%)`;
              }
            }
          }
        }
      }
    });
  }

  // Traffic Chart (Line)
  const trafficCtx = document.getElementById('trafficChart')?.getContext('2d');
  if (trafficCtx) {
    chartInstances.traffic = new Chart(trafficCtx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [{
          label: 'Traffic (req/min)',
          data: [],
          borderColor: CONFIG.CHART_COLORS.primary,
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          borderWidth: 3,
          pointBackgroundColor: 'var(--bg-card)',
          pointBorderColor: CONFIG.CHART_COLORS.primary,
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6,
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'var(--bg-elevated)',
            titleColor: 'var(--text-primary)',
            bodyColor: 'var(--text-secondary)',
            borderColor: 'var(--border-light)',
            borderWidth: 1
          }
        },
        scales: {
          x: {
            grid: { display: false, color: 'var(--border-light)' },
            ticks: { color: 'var(--text-secondary)' }
          },
          y: {
            grid: { color: 'var(--border-light)' },
            ticks: { 
              color: 'var(--text-secondary)',
              callback: value => formatNumber(value)
            }
          }
        }
      }
    });
  }

  // Threat Chart (Bar)
  const threatCtx = document.getElementById('threatChart')?.getContext('2d');
  if (threatCtx) {
    chartInstances.threat = new Chart(threatCtx, {
      type: 'bar',
      data: {
        labels: ['DDoS', 'Port Scan', 'Large Transfer', 'ICMP Flood'],
        datasets: [{
          data: [0, 0, 0, 0],
          backgroundColor: [
            CONFIG.CHART_COLORS.critical,
            CONFIG.CHART_COLORS.high,
            CONFIG.CHART_COLORS.medium,
            CONFIG.CHART_COLORS.low
          ],
          borderRadius: 8,
          barPercentage: 0.6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'var(--bg-elevated)',
            titleColor: 'var(--text-primary)',
            bodyColor: 'var(--text-secondary)'
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: 'var(--text-secondary)' }
          },
          y: {
            grid: { color: 'var(--border-light)' },
            ticks: { 
              color: 'var(--text-secondary)',
              callback: value => formatNumber(value)
            }
          }
        }
      }
    });
  }

  // Bandwidth Chart (Line)
  const bandwidthCtx = document.getElementById('bandwidthChart')?.getContext('2d');
  if (bandwidthCtx) {
    chartInstances.bandwidth = new Chart(bandwidthCtx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Incoming',
            data: [],
            borderColor: CONFIG.CHART_COLORS.primary,
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Outgoing',
            data: [],
            borderColor: CONFIG.CHART_COLORS.warning,
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            fill: true,
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { 
            mode: 'index', 
            intersect: false,
            backgroundColor: 'var(--bg-elevated)',
            titleColor: 'var(--text-primary)',
            bodyColor: 'var(--text-secondary)'
          }
        },
        scales: {
          x: { 
            grid: { display: false }, 
            ticks: { color: 'var(--text-secondary)' }
          },
          y: { 
            grid: { color: 'var(--border-light)' }, 
            ticks: { 
              color: 'var(--text-secondary)',
              callback: value => value + ' Mbps'
            }
          }
        }
      }
    });
  }
}

/* =========================
   WEBSOCKET CONNECTION
========================= */
function initWebSocket() {
  try {
    wsConnection = new WebSocket(CONFIG.WS_URL);
    
    wsConnection.onopen = () => {
      console.log('🔗 WebSocket connected - receiving real-time analytics');
      reconnectAttempts = 0;
      showNotification('Live data stream connected', 'success');
    };
    
    wsConnection.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'PACKETS' || data.type === 'PACKET') {
          // Update activity table
          if (data.data) {
            const packets = Array.isArray(data.data) ? data.data : [data.data];
            if (packets.length > 0) {
              trafficData = [...packets, ...trafficData].slice(0, 50);
              updateActivityTable(trafficData.slice(0, 8));
            }
          }
          
          // Refresh analytics to update charts (debounced)
          debouncedFetchAnalytics();
        }
        
        if (data.type === 'ALERTS' || data.type === 'ALERT') {
          // Update alert count
          fetchAlertCount();
          
          // Refresh threat data
          debouncedFetchAnalytics();
        }
        
        if (data.type === 'INIT' && data.mode) {
          if (elements.modeStatus) {
            elements.modeStatus.textContent = data.mode === 'demo' ? 'DEMO' : 'LIVE';
            elements.modeStatus.style.color = data.mode === 'demo' ? 'var(--warning)' : 'var(--success)';
          }
          isLive = data.mode !== 'demo';
        }
        
        if (data.type === 'ANALYTICS_UPDATE') {
          // Direct analytics update
          updateCharts(data.data);
          updateStats(data.data);
        }
        
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    wsConnection.onclose = () => {
      console.log('🔌 WebSocket disconnected');
      
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
        console.log(`🔄 Reconnecting in ${delay/1000}s... (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
        setTimeout(initWebSocket, delay);
      } else {
        showNotification('Live updates disconnected - using polling', 'warning');
      }
    };
    
    wsConnection.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
  } catch (error) {
    console.error('Failed to connect WebSocket:', error);
  }
}

// Debounce function for analytics refresh
let analyticsTimeout;
function debouncedFetchAnalytics() {
  clearTimeout(analyticsTimeout);
  analyticsTimeout = setTimeout(() => {
    fetchAnalytics();
  }, 500);
}

/* =========================
   FORMAT NUMBER
========================= */
function formatNumber(num) {
  if (num === null || num === undefined) return '0';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

/* =========================
   FORMAT BYTES
========================= */
function formatBytes(bytes) {
  if (bytes === 0 || !bytes) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/* =========================
   NOTIFICATION SYSTEM
========================= */
function showNotification(message, type = "info") {
  const existing = document.querySelector('.notification');
  if (existing) existing.remove();
  
  const notification = document.createElement("div");
  
  const icon = type === 'success' ? 'fa-check-circle' : 
               type === 'warning' ? 'fa-exclamation-triangle' : 
               type === 'error' ? 'fa-exclamation-circle' :
               'fa-info-circle';
  
  notification.innerHTML = `
    <i class="fas ${icon}"></i>
    <span>${message}</span>
  `;
  
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--bg-elevated);
    border-left: 4px solid ${type === 'success' ? 'var(--success)' : type === 'warning' ? 'var(--warning)' : type === 'error' ? 'var(--danger)' : 'var(--info)'};
    color: var(--text-primary);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    box-shadow: var(--shadow-lg);
    z-index: 2000;
    display: flex;
    align-items: center;
    gap: 1rem;
    animation: slideIn 0.3s ease;
    border: 1px solid var(--border-light);
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = "fadeOut 0.3s ease";
    notification.style.opacity = "0";
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

/* =========================
   FILTER HANDLERS
========================= */
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    
    const filter = this.dataset.filter;
    
    // Apply filter to activity table
    if (filter === 'all') {
      updateActivityTable(trafficData.slice(0, 8));
    } else if (filter === 'suspicious') {
      const filtered = trafficData.filter(p => 
        p.status === 'suspicious' || p.status === 'warning' || p.status === 'critical'
      );
      updateActivityTable(filtered.slice(0, 8));
    } else {
      const filtered = trafficData.filter(p => 
        p.protocol && p.protocol.toLowerCase() === filter
      );
      updateActivityTable(filtered.slice(0, 8));
    }
    
    showNotification(`Filtering by: ${filter}`, 'info');
  });
});

/* =========================
   SEARCH HANDLER
========================= */
if (elements.searchInput) {
  elements.searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    
    if (term.length > 2 && trafficData.length > 0) {
      const filtered = trafficData.filter(item => 
        (item.protocol && item.protocol.toLowerCase().includes(term)) ||
        (item.ip && item.ip.includes(term)) ||
        (item.dest && item.dest.includes(term)) ||
        (item.status && item.status.includes(term))
      );
      updateActivityTable(filtered.slice(0, 8));
    } else if (term.length === 0) {
      updateActivityTable(trafficData.slice(0, 8));
    }
  });
}

/* =========================
   REFRESH HANDLER
========================= */
if (elements.refreshBtn) {
  elements.refreshBtn.addEventListener('click', async () => {
    elements.refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
    elements.refreshBtn.disabled = true;
    
    await Promise.all([
      fetchAnalytics(),
      fetchTrafficData(),
      fetchAlertCount()
    ]);
    
    setTimeout(() => {
      elements.refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
      elements.refreshBtn.disabled = false;
      showNotification("Analytics refreshed", "success");
    }, 500);
  });
}

/* =========================
   EXPORT HANDLER
========================= */
if (elements.exportBtn) {
  elements.exportBtn.addEventListener('click', () => {
    elements.exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
    elements.exportBtn.disabled = true;
    
    // Generate CSV
    const csv = generateCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    
    setTimeout(() => {
      elements.exportBtn.innerHTML = '<i class="fas fa-download"></i> Export';
      elements.exportBtn.disabled = false;
      showNotification('Analytics exported successfully', 'success');
    }, 1000);
  });
}

function generateCSV() {
  const rows = [
    ['Metric', 'Value'],
    ['Total Packets', analyticsData.stats?.totalPackets || 0],
    ['Threats Blocked', analyticsData.stats?.threatsBlocked || 0],
    ['Active Sessions', analyticsData.stats?.activeSessions || 0],
    ['Packets/Second', analyticsData.stats?.packetsPerSecond || 0],
    ['Bandwidth In (Mbps)', analyticsData.bandwidth?.incoming || 0],
    ['Bandwidth Out (Mbps)', analyticsData.bandwidth?.outgoing || 0],
    [],
    ['Threat Type', 'Count'],
    ['DDoS', analyticsData.threats?.DDoS || 0],
    ['Port Scan', analyticsData.threats?.PortScan || 0],
    ['Large Transfer', analyticsData.threats?.LargeTransfer || 0],
    ['ICMP Flood', analyticsData.threats?.ICMPFlood || 0]
  ];
  
  return rows.map(row => row.join(',')).join('\n');
}

/* =========================
   TIME RANGE HANDLER
========================= */
if (elements.timeRange) {
  elements.timeRange.addEventListener('change', (e) => {
    const range = e.target.value;
    showNotification(`Loading ${range} data...`, 'info');
    
    // Could add specific API call for different ranges
    fetchAnalytics();
  });
}

/* =========================
   CHART ACTIONS
========================= */
window.toggleFullscreen = function(chartId) {
  const chart = document.getElementById(chartId);
  if (chart) {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      chart.parentElement.parentElement.requestFullscreen();
    }
  }
};

window.refreshChart = function(chartType) {
  showNotification(`Refreshing ${chartType} chart`, 'info');
  fetchAnalytics();
};

window.toggleUnit = function() {
  showNotification('Bandwidth unit toggled', 'info');
  // Could implement unit toggle here
};

/* =========================
   PRINT REPORT
========================= */
window.printReport = function() {
  window.print();
};

/* =========================
   GENERATE FULL REPORT
========================= */
window.generateReport = function() {
  showNotification('Generating full report...', 'info');
  
  // Create detailed report
  const report = {
    generated: new Date().toISOString(),
    analytics: analyticsData,
    traffic: trafficData.slice(0, 50)
  };
  
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `report-${new Date().toISOString().slice(0,19).replace(/:/g, '-')}.json`;
  a.click();
  
  showNotification('Report generated successfully', 'success');
};

/* =========================
   INITIALIZE ANALYTICS
========================= */
async function initAnalytics() {
  console.log('🔄 Initializing analytics with REAL-TIME data...');
  
  // Initialize charts first
  initCharts();
  
  // Check backend health
  const backendAvailable = await checkBackendHealth();
  
  if (backendAvailable) {
    // Fetch real data
    await Promise.all([
      fetchAnalytics(),
      fetchTrafficData(),
      fetchAlertCount()
    ]);
    
    // Connect WebSocket for real-time updates
    initWebSocket();
    
    // Set up periodic refresh as fallback
    if (refreshInterval) clearInterval(refreshInterval);
    refreshInterval = setInterval(async () => {
      if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
        console.log('Using HTTP polling fallback');
        await fetchAnalytics();
        await fetchTrafficData();
        await fetchAlertCount();
      }
    }, CONFIG.REFRESH_INTERVAL);
    
    showNotification('Analytics initialized - LIVE mode', 'success');
    
  } else {
    // Backend not available
    showNotification('Backend server not connected', 'error');
    
    // Show error in tables
    if (elements.activityBody) {
      elements.activityBody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; padding: 2rem;">
            <i class="fas fa-exclamation-triangle" style="color: var(--danger); font-size: 2rem; margin-bottom: 1rem;"></i>
            <p style="color: var(--text-secondary);">Backend server not connected</p>
            <p style="color: var(--text-secondary); font-size: 0.9rem;">Please start the backend on port 3000</p>
            <button class="btn-action" style="margin-top: 1rem;" onclick="location.reload()">
              <i class="fas fa-sync-alt"></i> Retry Connection
            </button>
          </td>
        </tr>
      `;
    }
    
    if (elements.topSourcesBody) {
      elements.topSourcesBody.innerHTML = `
        <tr>
          <td colspan="3" style="text-align: center; padding: 1rem; color: var(--text-secondary);">
            Waiting for backend connection...
          </td>
        </tr>
      `;
    }
  }
}

// ===== START ANALYTICS =====
initAnalytics();

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
  if (refreshInterval) clearInterval(refreshInterval);
  if (wsConnection) wsConnection.close();
});

console.log("✅ Analytics loaded successfully - REAL-TIME DATA ACTIVE");