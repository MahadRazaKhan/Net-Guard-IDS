console.log("🚀 NetGuard Dashboard Initialized");

// ===== CONFIGURATION =====
const CONFIG = {
  REFRESH_INTERVAL: 3000, // 3 seconds (faster refresh)
  API_ENDPOINTS: {
    traffic: '/api/traffic',
    analytics: '/api/analytics',
    stats: '/api/stats',
    health: '/api/health'
  },
  WS_URL: 'ws://localhost:8080'
};

// ===== DOM ELEMENTS =====
const elements = {
  tableBody: document.getElementById("trafficTableBody"),
  totalPackets: document.getElementById("totalPackets"),
  alerts: document.getElementById("alerts"),
  protocols: document.getElementById("protocols"),
  totalLogs: document.getElementById("totalLogs"),
  currentTime: document.getElementById("currentTime"),
  searchInput: document.getElementById("searchTraffic"),
  refreshBtn: document.getElementById("refreshDashboard"),
  chartContainer: document.getElementById("trafficChart"),
  showingStart: document.getElementById("showingStart"),
  showingEnd: document.getElementById("showingEnd"),
  totalEntries: document.getElementById("totalEntries"),
  exportBtn: document.getElementById("exportData"),
  modeStatus: document.getElementById("modeStatus"),
  sidebarAlertCount: document.getElementById("sidebarAlertCount")
};

// ===== STATE MANAGEMENT =====
let trafficData = [];
let analyticsData = {
  stats: {
    totalPackets: 0,
    threatsBlocked: 0,
    activeSessions: 0
  }
};
let wsConnection = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

// ===== UPDATE TIME =====
function updateTime() {
  if (!elements.currentTime) return;
  
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-US', { 
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  elements.currentTime.textContent = timeString;
}
setInterval(updateTime, 1000);
updateTime();

// ===== FETCH TRAFFIC DATA FROM BACKEND =====
async function fetchTrafficData() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.traffic + '?limit=50');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    if (data && Array.isArray(data)) {
      trafficData = data;
      renderTrafficTable(trafficData);
      updateStatsFromData();
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error fetching traffic data:', error);
    return false;
  }
}

// ===== FETCH ANALYTICS DATA =====
async function fetchAnalytics() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.analytics);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    analyticsData = data;
    
    // Update stats
    updateStatsFromAnalytics(data);
    
    // Update chart
    if (data.trafficOverTime) {
      updateChart(data.trafficOverTime);
    }
    
    return true;
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return false;
  }
}

// ===== FETCH STATS =====
async function fetchStats() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.stats);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    
    const data = await response.json();
    
    // Update stats display
    if (elements.totalPackets) {
      elements.totalPackets.textContent = formatNumber(data.totalPackets || 0);
    }
    
    if (elements.alerts) {
      elements.alerts.textContent = formatNumber(data.totalAlerts || 0);
    }
    
    if (elements.protocols) {
      elements.protocols.textContent = data.uniqueIPs || 
        new Set(trafficData.map(d => d.protocol)).size || 3;
    }
    
    if (elements.totalLogs) {
      elements.totalLogs.textContent = formatNumber(data.totalPackets || 0);
    }
    
    // Update sidebar alert count
    if (elements.sidebarAlertCount) {
      const unreadCount = data.unreadAlerts || 0;
      elements.sidebarAlertCount.textContent = unreadCount;
      elements.sidebarAlertCount.style.display = unreadCount > 0 ? 'inline-block' : 'none';
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching stats:', error);
    return null;
  }
}

// ===== UPDATE STATS FROM TRAFFIC DATA =====
function updateStatsFromData() {
  if (!trafficData) return;
  
  const suspicious = trafficData.filter(d => d.status === 'suspicious' || d.status === 'critical').length;
  const protocols = [...new Set(trafficData.map(d => d.protocol))].length;
  
  if (elements.alerts) elements.alerts.textContent = suspicious;
  if (elements.protocols) elements.protocols.textContent = protocols;
  if (elements.totalLogs) elements.totalLogs.textContent = trafficData.length;
}

// ===== UPDATE STATS FROM ANALYTICS =====
function updateStatsFromAnalytics(data) {
  if (!data || !data.stats) return;
  
  const stats = data.stats;
  
  if (elements.totalPackets) {
    elements.totalPackets.textContent = formatNumber(stats.totalPackets || 0);
  }
  
  if (elements.alerts) {
    elements.alerts.textContent = formatNumber(stats.threatsBlocked || 0);
  }
  
  if (elements.protocols) {
    elements.protocols.textContent = stats.uniqueIPs || 
      Object.keys(data.protocols || {}).length || 3;
  }
  
  if (elements.totalLogs) {
    elements.totalLogs.textContent = formatNumber(stats.totalPackets || 0);
  }
  
  // Update mode status
  if (elements.modeStatus) {
    elements.modeStatus.textContent = 'LIVE';
    elements.modeStatus.style.color = 'var(--success)';
  }
}

// ===== RENDER TRAFFIC TABLE =====
function renderTrafficTable(data) {
  if (!elements.tableBody) return;
  
  if (!data || data.length === 0) {
    elements.tableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 3rem;">
          <i class="fas fa-exchange-alt" style="font-size: 3rem; color: var(--text-muted); margin-bottom: 1rem;"></i>
          <p style="color: var(--text-secondary);">Waiting for network traffic...</p>
        </td>
      </tr>
    `;
    return;
  }
  
  elements.tableBody.innerHTML = "";
  
  data.slice(0, 10).forEach((item, index) => {
    const row = document.createElement("tr");
    row.style.animationDelay = `${index * 0.05}s`;
    
    // Determine status class
    const statusClass = item.status === 'critical' ? 'status-critical' : 
                       item.status === 'suspicious' || item.status === 'warning' ? 'status-warning' : 
                       'status-normal';
    
    const statusText = item.status ? item.status.toUpperCase() : 'NORMAL';
    
    row.innerHTML = `
      <td><code>${item.ip || 'Unknown'}</code></td>
      <td><span class="protocol-badge">${item.protocol || 'TCP'}</span></td>
      <td>${item.size || formatBytes(item.rawSize || 0)}</td>
      <td>${item.time || new Date().toLocaleTimeString()}</td>
      <td><span class="status-badge ${statusClass}">${statusText}</span></td>
      <td>
        <button class="btn-action" style="padding: 0.3rem 1rem; font-size: 0.8rem;" onclick="inspectIP('${item.ip || ''}')">
          <i class="fas fa-search"></i> Inspect
        </button>
      </td>
    `;
    
    elements.tableBody.appendChild(row);
  });
  
  // Update showing entries
  if (elements.showingStart) elements.showingStart.textContent = "1";
  if (elements.showingEnd) elements.showingEnd.textContent = Math.min(10, data.length);
  if (elements.totalEntries) elements.totalEntries.textContent = data.length;
}

// ===== UPDATE CHART WITH REAL DATA =====
function updateChart(trafficOverTime) {
  if (!elements.chartContainer || !trafficOverTime) return;
  
  elements.chartContainer.innerHTML = "";
  
  // Use real data if available
  const dataPoints = trafficOverTime.slice(-12); // Last 12 points
  
  if (dataPoints.length === 0) {
    // Fallback to sample data
    renderSampleChart();
    return;
  }
  
  const maxValue = Math.max(...dataPoints.map(d => d.packets || d.requests || 0));
  
  dataPoints.forEach((point, index) => {
    const barWrapper = document.createElement("div");
    barWrapper.style.flex = "1";
    barWrapper.style.display = "flex";
    barWrapper.style.flexDirection = "column";
    barWrapper.style.alignItems = "center";
    barWrapper.style.gap = "0.5rem";
    
    const bar = document.createElement("div");
    bar.className = "chart-bar";
    
    const value = point.packets || point.requests || 0;
    const height = maxValue > 0 ? Math.max(30, (value / maxValue) * 150) : 30;
    bar.style.height = `${height}px`;
    
    const label = point.time || `${index}:00`;
    bar.setAttribute("data-label", label);
    bar.setAttribute("data-count", formatNumber(value));
    
    // Color based on traffic
    if (value > maxValue * 0.8) {
      bar.style.background = 'linear-gradient(to top, var(--danger), var(--warning))';
    } else if (value > maxValue * 0.5) {
      bar.style.background = 'linear-gradient(to top, var(--warning), var(--secondary))';
    } else {
      bar.style.background = 'linear-gradient(to top, var(--secondary), var(--secondary-glow))';
    }
    
    barWrapper.appendChild(bar);
    elements.chartContainer.appendChild(barWrapper);
  });
}

// ===== SAMPLE CHART FALLBACK =====
function renderSampleChart() {
  if (!elements.chartContainer) return;
  
  elements.chartContainer.innerHTML = "";
  
  const hours = ['00', '02', '04', '06', '08', '10', '12', '14', '16', '18', '20', '22'];
  
  hours.forEach((hour, index) => {
    const barWrapper = document.createElement("div");
    barWrapper.style.flex = "1";
    barWrapper.style.display = "flex";
    barWrapper.style.flexDirection = "column";
    barWrapper.style.alignItems = "center";
    barWrapper.style.gap = "0.5rem";
    
    const bar = document.createElement("div");
    bar.className = "chart-bar";
    
    const height = Math.floor(Math.random() * 150) + 30;
    bar.style.height = `${height}px`;
    bar.setAttribute("data-label", `${hour}:00`);
    bar.setAttribute("data-count", Math.floor(Math.random() * 2000) + 500);
    
    barWrapper.appendChild(bar);
    elements.chartContainer.appendChild(barWrapper);
  });
}

// ===== RENDER CHART (Wrapper) =====
function renderChart() {
  if (analyticsData.trafficOverTime) {
    updateChart(analyticsData.trafficOverTime);
  } else {
    renderSampleChart();
  }
}

// ===== SEARCH FUNCTIONALITY =====
if (elements.searchInput) {
  elements.searchInput.addEventListener("input", (e) => {
    const term = e.target.value.toLowerCase();
    
    if (!trafficData || trafficData.length === 0) return;
    
    const filtered = trafficData.filter(item => 
      (item.ip && item.ip.toLowerCase().includes(term)) || 
      (item.protocol && item.protocol.toLowerCase().includes(term)) ||
      (item.status && item.status.toLowerCase().includes(term))
    );
    
    renderTrafficTable(filtered);
  });
}

// ===== REFRESH BUTTON =====
if (elements.refreshBtn) {
  elements.refreshBtn.addEventListener("click", async () => {
    elements.refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
    elements.refreshBtn.disabled = true;
    
    await Promise.all([
      fetchTrafficData(),
      fetchAnalytics(),
      fetchStats()
    ]);
    
    setTimeout(() => {
      elements.refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
      elements.refreshBtn.disabled = false;
      showNotification("Dashboard refreshed", "success");
    }, 500);
  });
}

// ===== EXPORT BUTTON =====
if (elements.exportBtn) {
  elements.exportBtn.addEventListener("click", () => {
    elements.exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
    elements.exportBtn.disabled = true;
    
    // Create CSV
    const csv = convertToCSV(trafficData);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `traffic-data-${new Date().toISOString()}.csv`;
    a.click();
    
    setTimeout(() => {
      elements.exportBtn.innerHTML = '<i class="fas fa-download"></i> Export';
      elements.exportBtn.disabled = false;
      showNotification("Data exported successfully", "success");
    }, 1000);
  });
}

// ===== CONVERT TO CSV =====
function convertToCSV(data) {
  if (!data || data.length === 0) return '';
  
  const headers = ['IP', 'Protocol', 'Size', 'Time', 'Status'];
  const rows = data.map(item => [
    item.ip || '',
    item.protocol || '',
    item.size || '',
    item.time || '',
    item.status || ''
  ]);
  
  return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
}

// ===== INSPECT FUNCTION =====
window.inspectIP = function(ip) {
  showNotification(`Inspecting IP: ${ip}`, "info");
  // You can open a modal or navigate to details page
};

// ===== NOTIFICATION SYSTEM =====
function showNotification(message, type = "info") {
  // Remove existing notifications
  const existing = document.querySelector('.notification');
  if (existing) existing.remove();
  
  const notification = document.createElement("div");
  notification.className = `notification notification-${type}`;
  
  const icon = type === 'success' ? 'fa-check-circle' : 
               type === 'warning' ? 'fa-exclamation-triangle' : 
               'fa-info-circle';
  
  notification.innerHTML = `
    <i class="fas ${icon}"></i>
    <span>${message}</span>
  `;
  
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--bg-elevated);
    border-left: 4px solid ${type === 'success' ? 'var(--success)' : type === 'warning' ? 'var(--warning)' : 'var(--info)'};
    color: var(--text-primary);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    box-shadow: var(--shadow-lg);
    z-index: 2000;
    display: flex;
    align-items: center;
    gap: 1rem;
    animation: slideIn 0.3s ease;
    border: 1px solid var(--border-light);
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = "fadeOut 0.3s ease";
    notification.style.opacity = "0";
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// ===== WEBSOCKET CONNECTION FOR REAL-TIME UPDATES =====
function initWebSocket() {
  try {
    wsConnection = new WebSocket(CONFIG.WS_URL);
    
    wsConnection.onopen = () => {
      console.log('🔗 WebSocket connected - receiving real-time data');
      reconnectAttempts = 0;
      showNotification('Connected to live data stream', 'success');
    };
    
    wsConnection.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === 'PACKET' || data.type === 'PACKETS') {
          // New packet received - update table
          const packets = data.data ? (Array.isArray(data.data) ? data.data : [data.data]) : [];
          
          if (packets.length > 0) {
            // Add to traffic data
            trafficData = [...packets, ...trafficData].slice(0, 100);
            renderTrafficTable(trafficData.slice(0, 10));
            
            // Update total packets count
            if (elements.totalPackets) {
              const current = parseInt(elements.totalPackets.textContent.replace(/[^0-9]/g, '')) || 0;
              elements.totalPackets.textContent = formatNumber(current + packets.length);
            }
          }
        }
        
        if (data.type === 'ALERT' || data.type === 'ALERTS') {
          // New alert - update badge
          fetchStats();
          
          // Show notification for critical alerts
          if (data.data && !Array.isArray(data.data)) {
            const alert = data.data;
            if (alert.severity === 'critical' || alert.severity === 'high') {
              showNotification(`🚨 ${alert.title || 'New Alert'}`, 'warning');
            }
          }
        }
        
        if (data.type === 'INIT') {
          // Initial connection data
          if (data.stats) {
            if (elements.totalPackets) {
              elements.totalPackets.textContent = formatNumber(data.stats.totalPackets || 0);
            }
          }
          
          if (data.mode) {
            console.log(`📡 Mode: ${data.mode}`);
          }
        }
        
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    wsConnection.onclose = () => {
      console.log('🔌 WebSocket disconnected');
      
      // Try to reconnect
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        console.log(`🔄 Reconnecting... (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`);
        setTimeout(initWebSocket, 3000);
      } else {
        showNotification('Live updates disconnected', 'warning');
      }
    };
    
    wsConnection.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
  } catch (error) {
    console.error('Failed to connect WebSocket:', error);
  }
}

// ===== FORMAT NUMBER =====
function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

// ===== FORMAT BYTES =====
function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  if (!bytes) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// ===== CHECK BACKEND HEALTH =====
async function checkBackendHealth() {
  try {
    const response = await fetch(CONFIG.API_ENDPOINTS.health);
    if (response.ok) {
      const data = await response.json();
      console.log(`✅ Backend connected - Mode: ${data.mode || 'live'}`);
      
      if (elements.modeStatus) {
        elements.modeStatus.textContent = data.mode === 'demo' ? 'DEMO' : 'LIVE';
        elements.modeStatus.style.color = data.mode === 'demo' ? 'var(--warning)' : 'var(--success)';
      }
      
      return true;
    }
    return false;
  } catch (error) {
    console.warn('⚠️ Backend not available');
    if (elements.modeStatus) {
      elements.modeStatus.textContent = 'OFFLINE';
      elements.modeStatus.style.color = 'var(--danger)';
    }
    return false;
  }
}

// ===== PAGE CHANGE HANDLERS =====
document.querySelectorAll('.page-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    if (this.disabled) return;
    
    document.querySelectorAll('.page-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    
    // Simulate page change or implement real pagination
    showNotification(`Page changed`, "info");
  });
});

// ===== CHART BUTTON HANDLERS =====
document.querySelectorAll('.chart-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    
    // Could implement different time ranges here
    showNotification(`View: ${this.textContent.trim()}`, "info");
  });
});

// ===== INITIALIZE DASHBOARD =====
async function initDashboard() {
  console.log('🔄 Initializing dashboard...');
  
  // Check backend health first
  const backendAvailable = await checkBackendHealth();
  
  if (backendAvailable) {
    // Fetch real data from backend
    await Promise.all([
      fetchTrafficData(),
      fetchAnalytics(),
      fetchStats()
    ]);
    
    // Initialize WebSocket for real-time updates
    initWebSocket();
    
    // Set up periodic refresh (fallback if WebSocket fails)
    setInterval(async () => {
      if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
        await fetchTrafficData();
        await fetchAnalytics();
        await fetchStats();
      }
    }, CONFIG.REFRESH_INTERVAL);
    
  } else {
    // Backend not available - show error
    showNotification('Backend server not connected', 'warning');
    
    elements.tableBody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 3rem;">
          <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: var(--danger); margin-bottom: 1rem;"></i>
          <h3 style="color: var(--text-primary); margin-bottom: 0.5rem;">Backend Not Connected</h3>
          <p style="color: var(--text-secondary);">Please start the backend server on port 3000</p>
          <button class="btn-action" style="margin-top: 1rem;" onclick="location.reload()">
            <i class="fas fa-sync-alt"></i> Retry Connection
          </button>
        </td>
      </tr>
    `;
  }
  
  // Always render chart (will use sample if no data)
  renderChart();
}

// ===== START DASHBOARD =====
initDashboard();

console.log("✅ Dashboard loaded successfully - Ready for real-time data");